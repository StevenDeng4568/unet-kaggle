
import torch
import numpy as np
from PIL import Image
from unet.unet_model import UNet


def load_model(weight_path=None, n_channels=3, n_classes=2, bilinear=False, device=None):
    device = device or torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = UNet(n_channels=n_channels, n_classes=n_classes, bilinear=bilinear).to(device)
    if weight_path:
        state_dict = torch.load(weight_path, map_location=device)
        state_dict.pop('mask_values', None)
        model.load_state_dict(state_dict)
    model.eval()
    return model, device


def preprocess_image(img: Image.Image):
    arr = np.array(img.convert('RGB')).astype(np.float32) / 255.0
    arr = np.transpose(arr, (2, 0, 1))
    x = torch.from_numpy(arr).unsqueeze(0)
    return x


def predict_mask(model, device, img: Image.Image, threshold=0.5):
    x = preprocess_image(img).to(device)
    with torch.no_grad():
        logits = model(x)
        if logits.shape[1] == 1:
            pred = (torch.sigmoid(logits) > threshold).long().squeeze().cpu().numpy()
        else:
            pred = torch.argmax(logits, dim=1).squeeze().cpu().numpy()
    return (pred * 255).astype(np.uint8)
